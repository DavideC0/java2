package com.spring.impiegati;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringImpiegatiHibApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringImpiegatiHibApplication.class, args);
	}

}
