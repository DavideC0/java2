package com.spring.impiegati;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringImpiegatiHibApplicationTests {

	@Test
	void contextLoads() {
	}

}
